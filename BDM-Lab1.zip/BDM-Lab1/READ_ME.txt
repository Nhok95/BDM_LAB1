# Project (P1): Landing Zone

This is the code for the first delivery of the subject BDM. 

We have used Python and PyMongo to recreate the ingestion of data to the landing zone.
Dividing the last one into two subzones, the temporal one and the persistent one.
Having in the former one the raw data and in the second one the same data but with the addition of metadata and a clear shape

## Structure

There are two main folders:

- code: It contains all the requiered code of the project. Three classes (MongoDB.py, dataCollector.py and dataPersistenceLoader.py) and one main (P1.py).
- sources: It contains the data of two differents datasets (idealista and opendatabcn-income) and their corresponding lookup tables.

If some additional datasources are wanted to be added, a folder with the name of the dataset and all their files have to be create in the sources folder, adding of course the corresponding logic to the main (P1.py) code.

## Usage

In order to run the code, first it has to be checked that a mongod instance in the host is running.

In our case the host is:

```
host = '10.4.41.45'
port = 27017
```

(If the host is another, it can be changed in the main (P1.py), line 14.

And the command to run the mongod instance is the following (if using the VM given by the UPC):

```
~/BDM_Software/mongodb/bin/mongod --bind_ip_all --dbpath /home/bdm/BDM_Software/data/mongodb_data/
```

Once we are certain that the instance is running. The main code can be executed by running the command:

```
py P1.py
```

or

```
python P1.py
```

Once executed it can be check that, inside the sources folder, all the files inside the different datasets that have been processed have been moved to a folder called processed.
Also it can be seen, by running a mongo shell, that a 'p1_persistence_db' has been created and it can be explored by:

```
~/BDM_Software/mongodb/bin/mongo
```

And once inside it:

```
show dbs

use p1_persistence_db

show collections

db.persistent_idealista.findOne()
db.persistent_opendatabcn_income.findOne()
db.persistent_opendatabcn_avg_rent.findOne()
db.persistent_lookup_tables.findOne()
```

Of course a 'p1_temporal_db' is also created in the process, but as it is temporal, when all the files inside it are processed, 
which is the case as the main executes all the steps, it is deleted. So, if it is the case that both dbs are wanted to be seen, 
comment any of the persistent loads.

## Developers

Team-Locals12-P1-B:

ALBERT PITA ARGEMI
KLEBER ENRIQUE REYES ILLESCAS


